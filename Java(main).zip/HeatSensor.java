import java.util.Scanner;

class HeatSensor 
{
    Scanner input = new Scanner(System.in);
    private int heat;
    private boolean sendOut;
    private String robotName;
    
    public HeatSensor(String robotName, int Heat)
    {
        this.robotName = robotName;
        this.heat = heat;
        this.sendOut = heat <= 280;
    }
    public int getHeat()
    {
        return heat;  
    }
    public String getRobotName()
    {
        return robotName;
    }
    public boolean isSentOut()
    {
        return sendOut;
    }
    public void setrobotName(String robotName)
    {
        this.robotName = robotName;
    }
    public void setHeat(int heat)
    {
        int sensor = input.nextInt();
        this.heat = sensor;
        boolean sendOut = heat <= 300;
    }
}